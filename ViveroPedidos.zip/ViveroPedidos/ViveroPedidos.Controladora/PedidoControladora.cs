﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViveroPedidos.Modelo.Entidades;

namespace ViveroPedidos.Controladora
{
    public class PedidoControladora
    {
        public List<Pedido> Listar(DateTime? desde = null, DateTime? hasta = null, string? solicitante = null) => throw new NotImplementedException();
        public Pedido? ObtenerConDetalle(int id) => throw new NotImplementedException();
        public Pedido Registrar(DateTime fecha, string solicitanteNombre, string solicitanteDocumento, DateTime fechaRetiro, List<(int PlantaId, int Cantidad)> lineas) => throw new NotImplementedException();


    }
}
