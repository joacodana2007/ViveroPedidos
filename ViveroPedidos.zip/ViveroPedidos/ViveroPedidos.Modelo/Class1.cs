﻿namespace ViveroPedidos.Modelo
{
    public class Class1
    {

    }
}
