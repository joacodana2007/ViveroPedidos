﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViveroPedidos.Modelo.Entidades
{
    public class Pedido
    {
        public int Id { get; set; }
        public int Numero { get; set; } 
        public DateTime Fecha { get; set; }
        public string SolicitanteNombre { get; set; } = string.Empty;
        public string SolicitanteDocumento { get; set; } = string.Empty; 
        public DateTime FechaRetiro { get; set; }
        public int CantidadItems { get; set; } 

        // Relación de navegación hacia el detalle (maestro-detalle)
        public List<PedidoDetalle> Detalles { get; set; } = new List<PedidoDetalle>();
    }
}

