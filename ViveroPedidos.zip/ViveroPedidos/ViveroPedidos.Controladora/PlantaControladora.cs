﻿using System;
using System.Collections.Generic;
using ViveroPedidos.Modelo.Entidades;

namespace ViveroPedidos.Controladora
{
    public class PlantaControladora
    {
        public List<Planta> Listar(string? filtro = null) => throw new NotImplementedException();
        public List<Planta> ListarDisponibles() => throw new NotImplementedException();
        public void GuardarNuevo(string codigo, string nombreComun, string especie) => throw new NotImplementedException();
        public void Modificar(int id, string codigo, string nombreComun, string especie, bool disponible) => throw new NotImplementedException();
        public void MarcarNoDisponible(int id) => throw new NotImplementedException();
        public void Eliminar(int id) => throw new NotImplementedException();
    }
}