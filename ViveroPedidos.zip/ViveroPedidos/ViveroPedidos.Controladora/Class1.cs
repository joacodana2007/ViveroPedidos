﻿namespace ViveroPedidos.Controladora
{
    public class Class1
    {

    }
}
