﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViveroPedidos.Modelo.Entidades;

namespace ViveroPedidos.Modelo
{
    public class ViveroContext : DbContext
    {

        public DbSet<Planta> Plantas { get; set; }
        public DbSet<Pedido> Pedidos { get; set; }
        public DbSet<PedidoDetalle>  pedidoDetalles { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Cadena de conexión sugerida para LocalDB
                optionsBuilder.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;Database=ViveroPedidosDb;Trusted_Connection=True;TrustServerCertificate=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // 1. Configuración de Planta
            modelBuilder.Entity<Planta>(entity =>
            {
                entity.HasKey(p => p.Id);
                entity.HasIndex(p => p.Codigo).IsUnique();
                entity.Property(p => p.Codigo).IsRequired().HasMaxLength(20);
                entity.Property(p => p.NombreComun).IsRequired().HasMaxLength(120);
                entity.Property(p => p.Especie).IsRequired().HasMaxLength(120);
            });

            // 2. Configuración de Pedido
            modelBuilder.Entity<Pedido>(entity =>
            {
                entity.HasKey(p => p.Id);
                entity.HasIndex(p => p.Numero).IsUnique();
                entity.Property(p => p.Numero).IsRequired();
                entity.Property(p => p.Fecha).HasColumnType("date"); // Sin hora
                entity.Property(p => p.SolicitanteNombre).HasMaxLength(120);
                entity.Property(p => p.SolicitanteDocumento).HasMaxLength(30);
                entity.Property(p => p.FechaRetiro).HasColumnType("date"); // Sin hora
            });

            // 3. Configuración de PedidoDetalle (Relaciones y restricciones)
            modelBuilder.Entity<PedidoDetalle>(entity =>
            {
                entity.HasKey(pd => pd.Id);
                entity.Property(pd => pd.NombreHistorico).HasMaxLength(120);

                // Relación con Pedido: Borrado en cascada (si borras el pedido, se borran sus líneas)
                entity.HasOne<Pedido>()
                      .WithMany(p => p.Detalles)
                      .HasForeignKey(pd => pd.PedidoId)
                      .OnDelete(DeleteBehavior.Cascade);

                // Relación con Planta: Borrado RESTRINGIDO (no te deja borrar la planta si está en un pedido)
                entity.HasOne<Planta>()
                      .WithMany()
                      .HasForeignKey(pd => pd.PlantaId)
                      .OnDelete(DeleteBehavior.Restrict);
            });
        }
    }
}
