﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViveroPedidos.Modelo.Entidades
{
    public class Planta
    {

        public int Id {  get; set; }
        public string Codigo { get; set; }
        public string NombreComun {  get; set; }
        public string Especie { get; set; }
        public bool Disponible { get; set; }

    }
}
